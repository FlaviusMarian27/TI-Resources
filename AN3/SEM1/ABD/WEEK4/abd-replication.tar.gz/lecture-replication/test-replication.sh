#!/bin/bash

echo "================================================"
echo "Testing MySQL Replication"
echo "================================================"
echo ""

# Insert test data on master
echo "Step 1: Inserting test data on MASTER..."
docker exec mysql-master mysql -uroot -prootpassword testdb -e "
    INSERT INTO users (username, email) VALUES 
        ('test_user', 'test@example.com'),
        ('replication_test', 'replication@example.com');
"
echo "Data inserted on master!"
echo ""

# Wait a moment for replication
echo "Waiting 2 seconds for replication to propagate..."
sleep 2
echo ""

# Check data on master
echo "Step 2: Data on MASTER:"
echo "----------------------------------------"
docker exec mysql-master mysql -uroot -prootpassword testdb -e "
    SELECT * FROM users;
"
echo ""

# Check data on each slave
for i in 1 2 3; do
  port=$((3306 + i))
  echo "Step 3.$i: Data on SLAVE$i (port $port):"
  echo "----------------------------------------"
  docker exec mysql-slave$i mysql -uroot -prootpassword testdb -e "
        SELECT * FROM users;
    "
  echo ""
done

# Check replication status
echo "Step 4: Checking replication status..."
echo "================================================"
for i in 1 2 3; do
  echo ""
  echo "SLAVE$i Status:"
  echo "----------------------------------------"
  docker exec mysql-slave$i mysql -uroot -prootpassword -e "
        SHOW REPLICA STATUS\G
    " | grep -E "Slave_IO_Running|Slave_SQL_Running|Seconds_Behind_Master|Last_IO_Error|Last_SQL_Error|Replica_SQL_Running_State|Replica_IO_Running|Replica_SQL_Running|Replica_IO_State"
done

echo ""
echo "================================================"
echo "Test complete!"
echo "================================================"
echo ""
echo "If Slave_IO_Running and Slave_SQL_Running are both 'Yes',"
echo "and the data matches across all servers, replication is working!"
