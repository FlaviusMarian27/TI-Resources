#!/bin/bash

echo "================================================"
echo "MySQL Replication Setup Script"
echo "================================================"

# Wait for master to be ready
echo "Waiting for master to be ready..."
until docker exec mysql-master mysql -uroot -prootpassword -e "SELECT 1" &>/dev/null; do
  echo "Master not ready yet... waiting"
  sleep 3
done
echo "Master is ready!"

# Wait for slaves to be ready
for slave in mysql-slave1 mysql-slave2 mysql-slave3; do
  echo "Waiting for $slave to be ready..."
  until docker exec $slave mysql -uroot -prootpassword -e "SELECT 1" &>/dev/null; do
    echo "$slave not ready yet... waiting"
    sleep 3
  done
  echo "$slave is ready!"
done

echo ""
echo "All servers are ready. Configuring replication..."
echo ""

# Configure each slave
for slave in mysql-slave1 mysql-slave2 mysql-slave3; do
  echo "Configuring replication on $slave..."

  docker exec $slave mysql -uroot -prootpassword -e "
        STOP REPLICA;
        CHANGE REPLICATION SOURCE TO
            SOURCE_HOST='mysql-master',
            SOURCE_USER='replicator',
            SOURCE_PASSWORD='replicator_password',
            SOURCE_AUTO_POSITION=1;
        START REPLICA;
    "

  echo "$slave configured!"
  echo ""
done

echo "================================================"
echo "Replication setup complete!"
echo "================================================"
echo ""
echo "Checking replication status..."
echo ""

# Check replication status on all slaves
for slave in mysql-slave1 mysql-slave2 mysql-slave3; do
  echo "----------------------------------------"
  echo "Status for $slave:"
  echo "----------------------------------------"
  docker exec $slave mysql -uroot -prootpassword -e "SHOW REPLICA STATUS\G" | grep -E "Slave_IO_Running|Slave_SQL_Running|Seconds_Behind_Master|Last_Error"
  echo ""
done

echo "================================================"
echo "Setup complete! You can now test replication."
echo "================================================"
